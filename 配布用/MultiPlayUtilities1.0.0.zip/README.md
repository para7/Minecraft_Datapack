# マルチプレイ補助システム

マルチプレイ用のユーティリティツール集です。  
欲しい機能がありましたら動画のコメント欄やgithubのissue等に意見をお願いします。  

解説動画url: 

# 使い方

要管理者権限

/function mputils:config/menu

様々な機能を選択できます。

/function mputils:config/setdisplay_なんとかかんとか


